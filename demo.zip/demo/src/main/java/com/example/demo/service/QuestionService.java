package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

@Service
public class QuestionService {

    @Autowired
    QuestionRepository questionRepository;
    
    public List<Question> getAllQuestions(){
        return questionRepository.findAll();
    }

    public List<Question> getQuestionsByCategory(String category){
        return questionRepository.getQuestionsByCategory(category);
    }

    public Question addQuestion(Question question) {
        return questionRepository.save(question);
    }

    public Question updateQuestionById(int id,Question updateQuestion){
        Question ques= questionRepository.findById(id).orElse(null);
        if(updateQuestion.getCorrectOption()!= null && updateQuestion.getCorrectOption()!=ques.getCorrectOption() ){
            ques.setCorrectOption(updateQuestion.getCorrectOption());
        }
        if(updateQuestion.getCategory()!= null && updateQuestion.getCategory()!=ques.getCategory() ){
            ques.setCategory(updateQuestion.getCategory());
        }
        if(updateQuestion.getLevel()!= null && updateQuestion.getLevel()!=ques.getLevel() ){
            ques.setLevel(updateQuestion.getLevel());
        }
        if(updateQuestion.getOption_A()!= null && updateQuestion.getOption_A()!=ques.getOption_A() ){
            ques.setOption_A(updateQuestion.getOption_A());
        }
        if(updateQuestion.getOption_B()!= null && updateQuestion.getOption_B()!=ques.getOption_B() ){
            ques.setOption_B(updateQuestion.getOption_B());
        }
        if(updateQuestion.getOption_C()!= null && updateQuestion.getOption_C()!=ques.getOption_C() ){
            ques.setOption_C(updateQuestion.getOption_C());
        }
        if(updateQuestion.getOption_D()!= null && updateQuestion.getOption_D()!=ques.getOption_D() ){
            ques.setOption_D(updateQuestion.getOption_D());
        }
        if(updateQuestion.getQuestionText()!= null && updateQuestion.getQuestionText()!=ques.getQuestionText() ){
            ques.setQuestionText(updateQuestion.getQuestionText());
        }
        
        return questionRepository.save(ques);

    }

    public String deleteQuestionById(int id){
        questionRepository.deleteById(id);
        return "deleted";
    }
}
