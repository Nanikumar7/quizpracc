package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Question;
import com.example.demo.service.QuestionService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("/question")
public class QuestionController {

    @Autowired
    QuestionService questionService;
    
    @GetMapping("/getAllQuestions")
    public List<Question> getAllQuestions(){
        return questionService.getAllQuestions();
    }
    
    @GetMapping("/getQuestionsByCategory/{category}")
    public List<Question> getQuestionsByCategory(@PathVariable String category){
        return questionService.getQuestionsByCategory(category);
    }

    @PostMapping("addQuestion")
    public String addQuestion(@RequestBody Question question) {
        questionService.addQuestion(question);
      return "success";
    }
    
    @PutMapping("/updateQuestion/{id}")
    public String updateQuestionById(@PathVariable int id, @RequestBody Question updateQuestion){
        questionService.updateQuestionById(id,updateQuestion);
        return "suceess";
    }

    @DeleteMapping("/deleteQuestionById/{id}")
    public String deleteQuestionById(@PathVariable int id){
        questionService.deleteQuestionById(id);
        return "deleted";
    }
}
