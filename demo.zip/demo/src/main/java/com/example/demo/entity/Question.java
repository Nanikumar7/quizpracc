package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String questionText;
    private String option_A;
    private String option_B;
    private String option_C;
    private String option_D;
    private String correctOption;
    private String category;
    private String level;
    public Question(){
        
    }
    public Question(Integer id, String questionText, String option_A, String option_B, String option_C, String option_D,
            String correctOption, String category, String level) {
        this.id = id;
        this.questionText = questionText;
        this.option_A = option_A;
        this.option_B = option_B;
        this.option_C = option_C;
        this.option_D = option_D;
        this.correctOption = correctOption;
        this.category = category;
        this.level = level;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getQuestionText() {
        return questionText;
    }
    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }
    public String getOption_A() {
        return option_A;
    }
    public void setOption_A(String option_A) {
        this.option_A = option_A;
    }
    public String getOption_B() {
        return option_B;
    }
    public void setOption_B(String option_B) {
        this.option_B = option_B;
    }
    public String getOption_C() {
        return option_C;
    }
    public void setOption_C(String option_C) {
        this.option_C = option_C;
    }
    public String getOption_D() {
        return option_D;
    }
    public void setOption_D(String option_D) {
        this.option_D = option_D;
    }
    public String getCorrectOption() {
        return correctOption;
    }
    public void setCorrectOption(String correctOption) {
        this.correctOption = correctOption;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getLevel() {
        return level;
    }
    public void setLevel(String level) {
        this.level = level;
    }
}
